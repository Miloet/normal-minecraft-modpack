# Lethal Shaders

Lethal Shaders is a simple shaderpack which aims to recreate the visual style of [Lethal Company](https://store.steampowered.com/app/1966720/Lethal_Company/) in Minecraft.

This shaderpack looks best at moody brightness settings.