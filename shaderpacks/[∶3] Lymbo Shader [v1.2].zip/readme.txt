  _                     _           
 | |                   | |          
 | |    _   _ _ __ ___ | |__   ___  
 | |   | | | | '_ ` _ \| '_ \ / _ \ 
 | |___| |_| | | | | | | |_) | (_) |
 |______\__, |_| |_| |_|_.__/ \___/ 
         __/ |    made by DorNell8                  
        |___/     

Hi. if u read this you maybe want edit this shader (or just upload on another sites like minecraft-indide kekw)
	If yes - just open final.fsh and edit all what you want, goodluck!
	P.S all of code without comments

I fixed fabric!!! yeah
I add a Fog!!! yeah